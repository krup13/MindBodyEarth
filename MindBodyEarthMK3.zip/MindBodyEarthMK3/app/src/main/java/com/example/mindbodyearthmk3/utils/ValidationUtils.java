package com.example.mindbodyearthmk3.utils;

public class ValidationUtils {
}
